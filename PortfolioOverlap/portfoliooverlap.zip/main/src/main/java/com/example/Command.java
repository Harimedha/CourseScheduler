package com.example;

public interface Command {
    
    void process(String[] parts);
}
